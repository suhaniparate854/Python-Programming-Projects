import csv
import os
from datetime import datetime
import pandas as pd
import matplotlib.pyplot as plt

FILE_NAME = "expenses.csv"

# -------------------------------
# Create CSV if not exists
# -------------------------------
def init_file():
    if not os.path.exists(FILE_NAME):
        with open(FILE_NAME, mode="w", newline="") as file:
            writer = csv.writer(file)
            writer.writerow(["Date", "Type", "Category", "Amount"])

# -------------------------------
# Add Income or Expense
# -------------------------------
def add_entry():
    date = input("Enter date (YYYY-MM-DD): ")
    entry_type = input("Type (income/expense): ").lower()
    category = input("Category: ")
    amount = float(input("Amount: "))

    with open(FILE_NAME, mode="a", newline="") as file:
        writer = csv.writer(file)
        writer.writerow([date, entry_type, category, amount])

    print("✅ Entry added successfully!")

# -------------------------------
# Monthly Summary
# -------------------------------
def monthly_summary():
    month = input("Enter month (YYYY-MM): ")

    df = pd.read_csv(FILE_NAME)
    df["Date"] = pd.to_datetime(df["Date"])

    month_data = df[df["Date"].dt.strftime("%Y-%m") == month]

    income = month_data[month_data["Type"] == "income"]["Amount"].sum()
    expense = month_data[month_data["Type"] == "expense"]["Amount"].sum()

    print("\n📊 Monthly Summary")
    print("Income :", income)
    print("Expense:", expense)
    print("Savings:", income - expense)

# -------------------------------
# Export to Excel
# -------------------------------
def export_excel():
    df = pd.read_csv(FILE_NAME)
    df.to_excel("expense_report.xlsx", index=False)
    print("📁 Exported to expense_report.xlsx")

# -------------------------------
# Create Chart
# -------------------------------
def create_chart():
    df = pd.read_csv(FILE_NAME)
    summary = df.groupby("Type")["Amount"].sum()

    summary.plot(kind="bar")
    plt.title("Income vs Expense")
    plt.savefig("expense_chart.png")
    plt.close()

    print("📊 Chart saved as expense_chart.png")

# -------------------------------
# Menu
# -------------------------------
def main():
    init_file()

    while True:
        print("\n==== Expense Tracker ====")
        print("1. Add Income/Expense")
        print("2. Monthly Summary")
        print("3. Export to Excel")
        print("4. Create Chart")
        print("5. Exit")

        choice = input("Choose an option: ")

        if choice == "1":
            add_entry()
        elif choice == "2":
            monthly_summary()
        elif choice == "3":
            export_excel()
        elif choice == "4":
            create_chart()
        elif choice == "5":
            print("👋 Exiting...")
            break
        else:
            print("❌ Invalid choice")

if __name__ == "__main__":
    main()
