import requests
from bs4 import BeautifulSoup
import csv
import time

URL = "https://www.bbc.com/news"

def fetch_headlines():
    print("Fetching headlines...")
    response = requests.get(URL)

    if response.status_code != 200:
        print("Failed to fetch website")
        return []

    soup = BeautifulSoup(response.text, "lxml")
    headlines = []

    for h in soup.select("a.gs-c-promo-heading"):
        title = h.get_text(strip=True)
        link = "https://www.bbc.com" + h.get("href")

        headlines.append({
            "title": title,
            "url": link
        })

    return headlines

def save_to_csv(data):
    with open("headlines.csv", "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["title", "url"])
        writer.writeheader()
        writer.writerows(data)

    print("Saved to headlines.csv")

def main():
    headlines = fetch_headlines()
    time.sleep(2)   # delay (polite scraping)
    save_to_csv(headlines)

if __name__ == "__main__":
    main()
